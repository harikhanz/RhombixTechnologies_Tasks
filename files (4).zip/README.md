# To-Do List — Task 2

A to-do list app themed around index cards on a kraft-paper board. Add,
edit, and delete tasks; filter by All / Active / Done; check a task off and
it gets a hand-stamped "DONE" mark. Everything is saved to the browser's
local storage, so your list is still there next time you open the page.

## Files
- `index.html` — structure
- `style.css` — design system and the stamp interaction
- `script.js` — add / edit / delete / filter logic + local storage persistence

## Features
- **Add** — type in the field at the top and press Enter or "Pin it"
- **Edit** — click directly on a task's text and type; it saves when you click away
- **Complete** — click the circle to stamp a task done (click again to undo)
- **Delete** — the × on the right removes a card
- **Filter** — All / Active / Done tabs
- **Clear filed** — removes every completed task at once
- Persists automatically via `localStorage` — no backend needed

## Preview it
Just open `index.html` in a browser. No build step or server required.

## Submitting (per the internship instructions)
1. Push this folder's contents to your `RhombixTechnologies_Tasks` GitHub
   repository (e.g. in a `web-development/task-2-todo-list` folder).
2. Post your completed project on LinkedIn with a short video walkthrough,
   tagging @Rhombix Technologies, and link the GitHub repo.
3. Submit the repo link through the internship's submission form.
