(() => {
  const STORAGE_KEY = 'task-cards:tasks';

  const form = document.getElementById('intakeForm');
  const input = document.getElementById('taskInput');
  const list = document.getElementById('taskList');
  const emptyState = document.getElementById('emptyState');
  const countText = document.getElementById('countText');
  const clearDoneBtn = document.getElementById('clearDone');
  const tabs = document.querySelectorAll('.tab');

  let tasks = loadTasks();
  let filter = 'all';

  // ---------- persistence ----------
  function loadTasks() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (err) {
      console.error('Could not read saved tasks:', err);
      return [];
    }
  }

  function saveTasks() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch (err) {
      console.error('Could not save tasks:', err);
    }
  }

  // ---------- helpers ----------
  function makeId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  function formatDate(ts) {
    const d = new Date(ts);
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  }

  function filteredTasks() {
    if (filter === 'active') return tasks.filter(t => !t.done);
    if (filter === 'done') return tasks.filter(t => t.done);
    return tasks;
  }

  // ---------- rendering ----------
  function render() {
    list.innerHTML = '';
    const visible = filteredTasks();

    emptyState.hidden = visible.length !== 0;
    emptyState.textContent = tasks.length === 0
      ? 'The board is clear. File something above.'
      : `Nothing filed under “${filter}”.`;

    visible.forEach(task => list.appendChild(renderCard(task)));

    const openCount = tasks.filter(t => !t.done).length;
    const doneCount = tasks.length - openCount;
    countText.textContent = `${openCount} open · ${doneCount} filed`;
  }

  function renderCard(task) {
    const li = document.createElement('li');
    li.className = 'card' + (task.done ? ' is-done' : '');
    li.dataset.id = task.id;

    li.innerHTML = `
      <button class="card__box" type="button" aria-label="${task.done ? 'Mark as active' : 'Mark as done'}"></button>
      <div class="card__body">
        <div class="card__text" contenteditable="true" spellcheck="false">${escapeHtml(task.text)}</div>
        <div class="card__meta">filed ${formatDate(task.createdAt)}</div>
      </div>
      <button class="card__delete" type="button" aria-label="Delete task">&times;</button>
      <span class="card__stamp">DONE</span>
    `;

    // toggle done
    li.querySelector('.card__box').addEventListener('click', () => {
      task.done = !task.done;
      saveTasks();
      render();
    });

    // inline edit
    const textEl = li.querySelector('.card__text');
    textEl.addEventListener('blur', () => {
      const newText = textEl.textContent.trim();
      if (newText === '') {
        textEl.textContent = task.text; // don't allow emptying via edit
        return;
      }
      if (newText !== task.text) {
        task.text = newText;
        saveTasks();
      }
    });
    textEl.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        textEl.blur();
      }
    });

    // delete with a small exit animation
    li.querySelector('.card__delete').addEventListener('click', () => {
      li.classList.add('is-leaving');
      li.addEventListener('animationend', () => {
        tasks = tasks.filter(t => t.id !== task.id);
        saveTasks();
        render();
      }, { once: true });
    });

    return li;
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // ---------- events ----------
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    tasks.unshift({ id: makeId(), text, done: false, createdAt: Date.now() });
    saveTasks();
    input.value = '';
    render();
  });

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => {
        t.classList.remove('is-active');
        t.setAttribute('aria-selected', 'false');
      });
      tab.classList.add('is-active');
      tab.setAttribute('aria-selected', 'true');
      filter = tab.dataset.filter;
      render();
    });
  });

  clearDoneBtn.addEventListener('click', () => {
    if (!tasks.some(t => t.done)) return;
    tasks = tasks.filter(t => !t.done);
    saveTasks();
    render();
  });

  // ---------- init ----------
  render();
})();
