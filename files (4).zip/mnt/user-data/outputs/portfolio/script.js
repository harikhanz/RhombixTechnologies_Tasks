(() => {
  const sections = document.querySelectorAll('main .spread, .colophon');
  const tocLinks = document.querySelectorAll('.toc a');

  const linkFor = (id) => document.querySelector(`.toc a[href="#${id}"]`);

  // ---------- scroll-spy: highlight the current section in the TOC ----------
  if ('IntersectionObserver' in window && sections.length) {
    const spy = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        const link = linkFor(entry.target.id);
        if (!link) return;
        if (entry.isIntersecting) {
          tocLinks.forEach(l => l.removeAttribute('aria-current'));
          link.setAttribute('aria-current', 'true');
        }
      });
    }, { rootMargin: '-40% 0px -55% 0px', threshold: 0 });

    sections.forEach(section => { if (section.id) spy.observe(section); });
  }

  // ---------- gentle reveal on scroll ----------
  const revealTargets = document.querySelectorAll('.spread');
  if ('IntersectionObserver' in window && revealTargets.length) {
    revealTargets.forEach(el => { el.style.opacity = '0'; el.style.transform = 'translateY(10px)'; });

    const reveal = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });

    revealTargets.forEach(el => reveal.observe(el));
  }
})();

// Respect reduced-motion users by skipping the reveal animation
if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  document.querySelectorAll('.spread').forEach(el => {
    el.style.opacity = '1';
    el.style.transform = 'none';
    el.style.transition = 'none';
  });
}
