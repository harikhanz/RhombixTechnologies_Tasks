# Personal Portfolio — Task 1

A single-page portfolio site built as an editorial "magazine issue": a
masthead, a table of contents, and numbered spreads for each required
section (About, Background, Skills, Projects, Experience, Testimonials,
Writing, Achievements, Contact).

## Files
- `index.html` — structure and content
- `style.css` — design system (colors, type, layout)
- `script.js` — scroll-spy on the table of contents + a subtle reveal-on-scroll

## Customize it
Open `index.html` and replace every `[bracketed placeholder]` with your own
information — name, education, projects, skills, experience, testimonials,
and contact links. No other files need to change unless you want to adjust
the design.

## Preview it
Just open `index.html` in a browser. No build step or server required.

## Submitting (per the internship instructions)
1. Push this folder's contents to your `RhombixTechnologies_Tasks` GitHub
   repository (e.g. in a `web-development/task-1-portfolio` folder).
2. Post your completed project on LinkedIn with a short video walkthrough,
   tagging @Rhombix Technologies, and link the GitHub repo.
3. Submit the repo link through the internship's submission form.
